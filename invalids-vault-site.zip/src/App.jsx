import React from "react";

export default function App() {
  return (
    <div style={{background:"black", color:"white", height:"100vh", display:"flex", justifyContent:"center", alignItems:"center"}}>
      <h1>INVALIDS VAULT 🔥</h1>
    </div>
  );
}
